const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");

module.exports = {
    name: "about",
    category: "Information",
    aliases: [ "botinfo" ],
    description: "See description about this project",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
     
    const row = new MessageActionRow()
			.addComponents(
    new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot`),
    new MessageButton()
    .setLabel("GitHub")
    .setStyle("LINK")
    .setURL("https://github.com"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/fzop")
			);

      const mainPage = new MessageEmbed()
            .setAuthor({ name: ' Crispy Music', iconURL: 'https://media.discordapp.net/attachments/848660510881742938/929330832508854323/926859201660219452.gif'})
           .setDescription(` **Hello I Am Crispy Devloped In javascript**, \n **Invite Me And enjoy Best quality More features soon** \n\n <:flex_hearts:932543753200222248> **Join support server** \n \n\n **Developed by** - <:os_RAGE_of_administrator:926063180797587487><@553934203352383490>
**Owner's - <:B_GoldModbadge:932537709250109460><@830662633806889001>,<:B_GoldModbadge:932537709250109460><@808621476542414860>
, <:B_GoldModbadge:932537709250109460><@842279130943062026> Thanks To all For supporting Crispy** \n `)                  .setColor('#303236')
      message.react('932714525403267092')
            return message.reply({embeds: [mainPage], components: [row]});
    }
}
