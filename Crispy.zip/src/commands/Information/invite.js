const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "invite",
    category: "Information",
    aliases: [ "addme" ],
    description: "invite LavaMusic",
    args: false,
    usage: "",
    permission: [],
    owner: false,
   execute: async (message, args, client, prefix) => {
         
         
    const row = new MessageActionRow()
			.addComponents(
    new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot`),
    new MessageButton()
    .setLabel("GitHub")
    .setStyle("LINK")
    .setURL("https://github.com/nilay7488"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/fzop")
			);

          const mainPage = new MessageEmbed()
            .setAuthor({ name: 'CrispyMusic', iconURL: 'https://media.discordapp.net/attachments/848660510881742938/955010944096940072/download.png'})
            .setThumbnail("https://media.discordapp.net/attachments/848660510881742938/955010944096940072/download.png")
            .setColor('#303236')
            .setImage("https://media.discordapp.net/attachments/848660510881742938/946385886919159858/standard_4.gif")
            .addField('invite Crispymusic', `[Here](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot)`, true)
           message.reply({embeds: [mainPage], components: [row]})
    }
}
