const MusicBot = require("./structures/MusicClient");

const client = new MusicBot();
require('http').createServer((req, res) => res.end('Bot is alive!')).listen(3010) 




client.connect()

module.exports = client; 
